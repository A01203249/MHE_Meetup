
from bs4 import BeautifulSoup
import numpy as np
import re
import pandas as pd
import matplotlib.pyplot as plt

# Map colors
### GRAYSCALE
# colors = ["#ffffff", "#f0f0f0", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525"]
# colors = ["#f7f7f7", "#d9d9d9", "#bdbdbd", "#969696", "#636363", "#252525"]
# colors = ["#f7f7f7", "#cccccc", "#969696", "#525252"]

### REDS
# colors = ["#FFF5F0", "#FEE0D2", "#FCBBA1", "#FC9272", "#FB6A4A", "#EF3B2C", "#CB181D", "#99000D"]
# colors = ["#fee5d9", "#fcbba1", "#fc9272", "#fb6a4a", "#de2d26", "#a50f15"]
# colors = ["#FEE5D9", "#FCAE91", "#FB6A4A", "#CB181D"]

### Y/OR/RED
colors = ["#FFFFCC", "#FFEDA0", "#FED976", "#FEB24C", "#FD8D3C", "#FC4E2A", "#E31A1C", "#B10026"]
# colors = ["#FFFFB2", "#FED976", "#FEB24C", "#FD8D3C", "#F03B20", "#BD0026"]
color = {"Special Needs":'b',
         'Health & Sports':"g",
         'Math & Science':"r",
         "Music & The Arts":"c",
         "Applied Learning":"m",
         "Literacy & Language":"y",
         "History & Civics":"k"}

project = pd.read_csv('opendata_projects.csv')
project.ix[project['school_state'] == 'La','school_state'] = 'LA'
project['count'] = 1

def get_count(data,subject):
    return data[data['primary_focus_area'] == key]['count'].sum()

store_success = np.zeros((len(set(project.school_state)), len(color)))
store_fail = np.zeros((len(set(project.school_state)), len(color)))

row = 0
store_state = []
for state, value in project.groupby('school_state'):
    store_state.append(state)
#     value = value[value['funding_status']=='completed']
#     index_success = numpy.logical_or(value.eligible_double_your_impact_match == 't' ,value.eligible_almost_home_match == 't')
    #value.eligible_double_your_impact_match == 't' or 
    index_success = value.funding_status == 'completed'
    index_failure = value.funding_status == 'expired'
    
    success = value[index_success]
    failure = value[index_failure]
    
    for s in [success, failure]:
        col = 0
        for key in sorted(color):
            store_success[row,col] = get_count(success, key)
            store_fail[row,col] = get_count(failure, key)
            col += 1
    row += 1

store_state = np.array(store_state)
success_rate = store_success/(store_success+store_fail)
index2keep = np.where(np.isnan(success_rate[:,0])== False)[0]
success_rate = success_rate[index2keep]
success_rate_pd = pd.DataFrame(success_rate,columns = sorted(color), index = store_state)
success_rate_pd = pd.DataFrame(success_rate,columns = sorted(color), index = store_state)

bins = plt.hist(success_rate.ravel(), bins = len(colors)-1)
path_style = 'fill:'
value = zip(success_rate_pd.index, np.digitize(success_rate_pd['Special Needs'].values, bins[1]))
value = dict((x,y) for x,y in value)


### Purple/Red color scheme. Replace line below with colors above to try others.



# Load the SVG map
svg = open('Blank_US_Map.svg', 'r').read()
soup = BeautifulSoup(svg)
paths = soup.findAll('path')
pattern_state = re.compile(r'\w+')


# Change colors accordingly
path_style = 'fill:'
for i in soup.findAll('path'):
    try:
        state = pattern_state.search(i['id']).group()
    except KeyError:
        continue

    if state in value:
        c = colors[value[state]-1]
    else:
        c = '#221e1f'
        
    i['style'] = path_style + c

print soup.prettify()