library(tm)
library(randomForest)
library(rpart)
library(rpart.plot)
library(ggplot2)


setwd('d:/Userfiles/asarapure/Downloads/Hackathon/')
prj = read.csv('opendata_projects.csv')
gift = read.csv('opendata_giftcards.csv')

essayData  = read.csv('essay_extract_0.csv')

merged = merge(essayData , prj , by = 'X_projectid')

#Function to create a corpus 
createCorpus = function(doc, sparsity){
  corpus = Corpus(VectorSource(doc))
  corpus = tm_map(corpus , tolower)
  corpus = tm_map(corpus , PlainTextDocument)
  corpus = tm_map(corpus, removePunctuation)
  corpus = tm_map(corpus, removeWords, stopwords("english"))
  #corpus = tm_map(corpus , stemDocument) 
  #Not stemming the words further.
  
  dtm = DocumentTermMatrix(corpus)
  dtm = removeSparseTerms(dtm, sparsity)
  df = as.data.frame(as.matrix(dtm))
}



title_df= createCorpus(essayData$title , 0.98)
shrt_desc_df = createCorpus(essayData$short_description, 0.93)
need_stmt_df = createCorpus(essayData$need_statement , 0.91)
essay_df = createCorpus(essayData$essay, 0.89)



fundstatus = merged$funding_status
fundWords = cbind(fundstatus, title_df)

live = fundWords[fundWords$fundstatus == 'live',]
#to remove live articles. But none found in ess0 extract. 

#Considering funding status completed as success (1), 0 otherwise
fun$fundstatus = ifelse(fun$fundstatus == 'completed' , 1, 0)

#Creating a Random Forest model to find out importance of words.
rf = randomForest(as.factor(fundstatus) ~ . , data = fun, ntree= 7)
varImpPlot(rf)


#logistic regression to find out positive and negative weighted categories
log.mdl = glm(as.factor(fundstatus) ~ . , data = fun, family = 'binomial')
summary(log.mdl)





#Function to create a logistic Regression Model
keywordAnalysis = function(textDF){
  fundWords = cbind(fundstatus, textDF)
  
  fundWords$fundstatus = ifelse(fun$fundstatus == 'completed' , 1, 0)
  
  log.mdl = glm(as.factor(fundstatus) ~ . , data = fundWords, family = 'binomial')
  print(summary(log.mdl))
  
}



keywordAnalysis(essay_df)
keywordAnalysis(shrt_desc_df)
keywordAnalysis(need_stmt_df)



#Creating the output file of tree model. 


png(filename="Std_PNG.png", 
    units="in", 
    width=9, 
    height=7, 
    pointsize=25, 
    res=152)
prp(tree)
dev.off()









