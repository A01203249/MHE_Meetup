Keyword Analysis of the text used to write grant proposals. 


The data can be found here - https://www.dropbox.com/sh/icvwfzra5s7z733/AACrHwR-YVuvrNj979rrBMZCa?dl=0

essay_extract_0 is not the complete file. But around 1/4th of it. 
Markdown file shows the exploratory analysis and it has been knitted into a html file. 
text_Analysis.R - R script to create Corpus of text, train models and find variable importance.